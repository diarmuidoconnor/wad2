fetch("https://jsonplaceholder.typicode.com/todos")
  .then(response => response.json())
  .then(json => {
    const todoscompletedByUser = json.reduce((acc, todo) => {
      todo.completed
        ? acc.push({ userId: todo.userId, title: todo.title })
        : acc;
      return acc;
    }, []);
    console.log(todoscompletedByUser);
  })
  .catch(function(err) {
    console.log(err);
  });
