
class Car { 
	constructor(name,address,make,model,cc,reg) {
		this.owner = name ;
		this.address = address;
		this.previous_owners = [];
		this.type = { make, model, cc };
		let regParts = reg.split('-');
		let year = parseInt(regParts[0].substring(0,2));
		let part = regParts[0].substring(2);
		this.registration = {year , 
			part,
			county : regParts[1], 
			number : regParts[2] } ;
    } 
	howOld() {
	    let today = new Date();
	    let this_year = today.getFullYear();
        return this_year - (this.registration.year + 2000);
	}
	newOwner(name,address) {
		this.addPreviousOwner(this.owner,this.address);
		this.owner = name;
		this.address = address;
	}
	addPreviousOwner(name,address) {
		let o = { name, address };
		if (this.previous_owners.length == 3) {
			this.previous_owners.shift();
		}
		this.previous_owners.push(o);
	}
	wasOwnedBy(name) {
		let match = this.previous_owners.find(
			(element,index) => element.name.toUpperCase() === name.toUpperCase() 
		);
	    return match !== undefined ? true : false;
	  }
}

export default Car;