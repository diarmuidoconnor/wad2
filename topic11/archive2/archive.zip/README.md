This archive contains the code demonstrating a custom solution for
protected routes and authentication in a React app. 
Run npm install followed by npm start. 

NOTE: REQUIRES SOLUTION FOR LAST LAB RUNNING ON localhost:8080