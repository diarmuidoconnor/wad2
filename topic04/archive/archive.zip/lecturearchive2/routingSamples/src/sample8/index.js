// See the following article for a detailed explanation of 
// this sample's code:
// https://www.robinwieruch.de/react-router-authentication/

import './version2/';
