import React from "react";

const Friend = ({friend}) => {
  return (
    <li >
      <h3>{` ${friend.name.first} ${friend.name.last}`}</h3>
      <a href={"mailto:" + friend.email}>
        {friend.email}{" "}
      </a>
    </li>
  );
};

export default Friend