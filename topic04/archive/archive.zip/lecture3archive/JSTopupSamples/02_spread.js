
// Spread - A new operator ... that takes an array and separates it 
// into its individual values

function myFunction(x, y, z) { 
     console.log (`y =  ${y}`) ;
}

let args = [0, 1, 2];
myFunction(...args);
myFunction(4, ...args);
// A more powerful array literal
const parts = ['shoulders', 'knees'];
const lyrics = ['head', ...parts, 'and', 'toes']; // ["head", "shoulders", "knees", "and", "toes"]
console.log(lyrics) ;
{ 
     // Inserting arrays
     const mid = [3, 4]
     let arr = [1, 2, mid, 5, 6]
     console.log(arr)
     arr = [1, 2, ...mid, 5, 6]
     console.log(arr)
}
{
     // Copy an array
     const arr1 = ['a', 'b', 'c']
     let arr2 = arr1    // Not copying
     arr2.push('d')
     console.log(arr1)
     arr2 = [...arr1]    // Is copying
     arr2.push('e')
     console.log(arr1)
}
{
     // String to array
     const hi = 'hello'
     const letters = [...hi]
     console.log(letters)
}
console.log('\n==================================\n')
// OBJECTS
{
     const partOfMe = {first: 'Diarmuid', address: '1 Main street'}
     let allMe = {surname: 'O Connor', partOfMe, employer: 'WIT'}
     console.log(allMe)
     allMe = {surname: 'O Connor', ...partOfMe, employer: 'WIT'}
     console.log(allMe)
}
{
     const me = { surname: 'O Connor', first: 'Diarmuid',
         address: '1 Main street', employer: 'WIT' }
     const updatedMe = { ...me, address: '2 High Street' }
     console.log(updatedMe)
}