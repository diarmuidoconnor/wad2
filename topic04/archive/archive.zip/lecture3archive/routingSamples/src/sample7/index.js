import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import Inbox from "./inbox";

const Home = () => {
  return (
    <>
      <h1>Home page</h1>
      <span>
        <b>Demo Alternative Route API:</b> Used for passing custom props to a
        Route's component
      </span>
      <p>
        Try <Link to="/inbox/1234/statistics">User 1234 with Stats</Link>
        <span> - Nested route uses alternative Route syntax.</span>{" "}
      </p>
      <p>
        Try <Link to="/inbox/4321/drafts">User 4321 with Drafte</Link>
        <span> - Nested route uses standard Route syntax.</span>{" "}
      </p>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/inbox/:userId" component={Inbox} />
        <Route exact path="/" component={Home} />
        <Redirect from="*" to="/" />
      </Switch>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
