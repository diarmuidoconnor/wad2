const hello = () =>{
    console.log("hello!")
}

export default hello;