import mygreeting from './greeting'

mygreeting()