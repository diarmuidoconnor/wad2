import React from 'react';
import ReactDOM from 'react-dom';
import FriendsApp from './App';

ReactDOM.render(
    <FriendsApp/>,
    document.getElementById('root')
);
