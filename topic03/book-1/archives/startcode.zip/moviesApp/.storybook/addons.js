module.exports = {
    addons: ['@storybook/addon-actions/register']
  }