import React, { useReducer, useEffect } from "react";
import FriendList from "./components/friendList";
import "./style.css";
import "../node_modules/bootstrap/dist/css/bootstrap.css";

const reducer = (state, action) => {
  switch (action.type) {
    case "add-to-confirmed":
      return {
        friends: state.friends.map((f) => {
          if (f.email === action.payload.friend.email) f.confirmed = true;
          return f;
        })
      };
    case "load-invitees":
      return {
        friends: action.payload.friends.map( f => {
          f.confirmed = false;
          return f
        })
      };
    case "remove-from-confirmed":
      return {
        friends: state.friends.map((f) => {
          if (f.email === action.payload.friend.email) f.confirmed = false;
          return f;
        })
      };
    default:
      return state;
  }
};

const PartyApp = () => {
  const [state, dispatch] = useReducer(reducer, {
    friends: [],
  });

  useEffect(() => {
    fetch("https://randomuser.me/api/?results=10")
      .then((response) => response.json())
      .then((json) => {
        dispatch({ type: "load-invitees", payload: { friends: json.results } });
      });
  }, []);

  const confirmationReceived = (friend) => {
    dispatch({ type: "add-to-confirmed", payload: { friend: friend } });
  };

  const cancellation = (friend) => {
    dispatch({ type: "remove-from-confirmed", payload: { friend: friend } });
  };

  const confirmations = state.friends.filter((f) => f.confirmed);
  const nonconfirmations = state.friends.filter((f) => !f.confirmed);

  return (
    <div className="jumbotron">
      <div className="container-fluid">
        <div className="row">
          <div className="col-6 offset-4">
            <h1>Zoom Party Manager</h1>
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <h2>Un-confirmed</h2>
            <FriendList list={nonconfirmations} action={confirmationReceived} />
          </div>
          <div className="col-6">
            <h2>Confirmed</h2>
            <FriendList list={confirmations} action={cancellation} />
          </div>
        </div>
      </div>
    </div>
  )
}

export default PartyApp;
