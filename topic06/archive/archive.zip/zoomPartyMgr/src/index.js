import React from 'react';
import ReactDOM from 'react-dom';
import PartyApp from './App';

ReactDOM.render(
    <PartyApp/>,
    document.getElementById('root')
);
