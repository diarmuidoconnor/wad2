import React from "react";

const Friend = (props) => {

  const onClick = (event) => {
    event.preventDefault();
    props.action(props.friend);
  };
  return (
    <li>
      <button className="friend" type="button" onClick={onClick}>
        <h3>{` ${props.friend.name.first} ${props.friend.name.last}`}</h3>
      </button>
    </li>
  );
};

export default Friend;
