This folder contains the Filtered Friends App that demonstrates the render props design pattern. 

To run it:

$ npm install
$ npm start
