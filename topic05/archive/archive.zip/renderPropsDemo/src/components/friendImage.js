import React from "react";

const FriendImage = props => {
 
  return (
    <li>
      <h3>{` ${props.friend.name.first} ${props.friend.name.last}`}</h3>
      <img src={props.friend.picture.medium} />
    </li>
  );
};

export default FriendImage