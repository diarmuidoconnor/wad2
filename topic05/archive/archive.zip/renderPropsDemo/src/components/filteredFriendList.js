import React from "react";
// import Friend from ....
const FilteredFriendList = (props) => {
  const friends = props.list.map((item) => 
      props.render(item)
  );
  return <ul>{friends}</ul>;
};

export default FilteredFriendList;
