import React, { useState, useEffect, createContext } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export const AuthContext = createContext(null);

const AuthContextProvider = ({ children }) => {
  const [token, setToken] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  const authenticate = (username, password) => {
    setTimeout(() => {
      setToken("2342f2f1d131rf12");
      const origin = location.state?.intent?.pathname || "/";
      navigate(origin);
    }, 250);
  };

  const signout = () => {
    setToken(null);
    navigate("/");
  };

  return (
    <AuthContext.Provider
      value={{
        token,
        authenticate,
        signout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContextProvider;
