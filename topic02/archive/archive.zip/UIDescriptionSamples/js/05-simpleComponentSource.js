const DynamicLanguages = () => {
  return (
    <div className="pad">
      <h1 className="heading">Dynamic Languages (Component)</h1>
      <ul>
        <li>Javascript</li>
        <li>PHP</li>
        <li>Python</li>
      </ul>
    </div>
  );
};
const rootElement = ReactDOM.createRoot(document.getElementById("mount-point"));
rootElement.render(<DynamicLanguages/>);
