const rootElement = (
  <div className="pad">
    <h1 className="heading">Languages</h1>
    <ul>
      <li>Javascript</li>
      <li>Java</li>
      <li>Python</li>
    </ul>
  </div>
);

ReactDOM.render(rootElement, document.getElementById("mount-point"));
