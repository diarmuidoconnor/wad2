import React from "react";
import JSXEnbeddedVars from "../../components/samples/02_embeddedVar";

export default {
  title: "Sample/02 - JSX embedded variable"  ,
  component: JSXEnbeddedVars,
};

export const Basic = () => {
  return <JSXEnbeddedVars />  ;
};
