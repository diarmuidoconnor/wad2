import React , { Component } from 'react';

export default class Child1 extends Component {
    render() {
        return <h2>I'm a child1 component </h2>
    }
}